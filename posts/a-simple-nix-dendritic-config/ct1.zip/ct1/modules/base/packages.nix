{
  flake.modules.nixos.base =
    { pkgs, ... }:
    {
      fonts.packages = with pkgs; [
        nerd-fonts.droid-sans-mono
        nerd-fonts.fira-code
        source-sans-pro
      ];

      environment.systemPackages = with pkgs; [
        unstable.nushell

        # Language servers
        bash-language-server
        clang-tools
        cmake-language-server
        nixd

        alacritty
        emacs-with-packages
        git
        pandoc
        polybar
        qutebrowser
        starship
      ];
    };
}
