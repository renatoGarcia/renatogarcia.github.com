{
  flake.modules.nixos.base =
    { modulesPath, ... }:
    {
      nix.extraOptions = "experimental-features = nix-command flakes";

      imports = [
        (modulesPath + "/installer/scan/not-detected.nix")
      ];

      boot = {
        loader.efi.canTouchEfiVariables = true;
        loader.systemd-boot.enable = true;
        tmp.useTmpfs = true;
      };

      hardware.bluetooth.enable = true;

      networking = {
        networkmanager.enable = true;
        useDHCP = false;
      };

      time.timeZone = "America/Sao_Paulo";

      services = {
        openssh.enable = true;
        blueman.enable = true;
        pipewire = {
          enable = true;
          pulse.enable = true;
        };
        desktopManager.gnome.enable = true;
        xserver = {
          enable = true;
          xkb.layout = "br";
          displayManager.lightdm.enable = true;
          windowManager.xmonad = {
            enable = true;
          };
        };
      };

      system.stateVersion = "20.09";

    };
}
