{
  self,
  inputs,
  ...
}:
{
  flake.modules.nixos.home-desktop =
    { pkgs, config, ... }:
    {
      imports = with self.modules.nixos; [
        base
        renatofg
        helena
      ];

      nixpkgs.hostPlatform = "x86_64-linux";

      boot = {
        initrd = {
          availableKernelModules = [
            "nvme"
            "xhci_pci"
            "ahci"
            "usbhid"
            "usb_storage"
            "sd_mod"
          ];
          kernelModules = [ ];
        };
        kernelModules = [ "kvm-amd" ];
        extraModulePackages = [ ];
      };

      services = {
        ollama.enable = true;
        xserver = {
          videoDrivers = [ "nvidia" ];
          displayManager.setupCommands = ''
            ${pkgs.xorg.xrandr}/bin/xrandr --output "HDMI-1" --right-of "HDMI-0"
          '';
        };
      };

      networking = {
        hostName = "home-desktop";
        interfaces.enp4s0.useDHCP = false;
        interfaces.enp5s0.useDHCP = false;
        interfaces.wlp6s0.useDHCP = false;
      };

      hardware = {
        nvidia-container-toolkit.enable = true;
        nvidia = {
          modesetting.enable = true;
          powerManagement.enable = false;
          powerManagement.finegrained = false;
          open = false;
          nvidiaSettings = true;
          package = config.boot.kernelPackages.nvidiaPackages.stable;
        };
      };

      environment.systemPackages = with pkgs; [
        nvitop
      ];

    };

  flake.nixosConfigurations.home-desktop = inputs.nixpkgs.lib.nixosSystem {
    modules = [

      self.modules.nixos.home-desktop

      inputs.home-manager.nixosModules.home-manager

      {
        home-manager = {
          useGlobalPkgs = true;
          users.renatofg = self.modules.homeManager.renatofg;
        };
      }

      {
        nixpkgs = {
          config = {
            nvidia.acceptLicense = true;
            cudaSupport = true;
            allowUnfree = true;
          };
          overlays = [ self.overlays.default ];
        };
      }

    ];
  };
}
