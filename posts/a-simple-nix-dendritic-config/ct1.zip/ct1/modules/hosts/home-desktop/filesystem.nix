{
  flake.modules.nixos.home-desktop = {
    fileSystems."/" = {
      device = "/dev/disk/by-uuid/9b54cf1c-c570-4779-97a2-897ae70f44c1";
      fsType = "ext4";
    };

    fileSystems."/boot" = {
      device = "/dev/disk/by-uuid/F783-6A4F";
      fsType = "vfat";
    };

    fileSystems."/home" = {
      device = "/dev/disk/by-uuid/8385c5a1-0027-467a-8b19-09325c0eab7b";
      fsType = "ext4";
    };

    fileSystems."/mnt/archives" = {
      device = "/dev/disk/by-uuid/dfdb139f-3016-4801-b631-0fadb9d14cfe";
      fsType = "ext4";
    };

    swapDevices = [ { device = "/dev/disk/by-uuid/acce19da-c19f-4a2a-8be6-51f0ac4cb5b0"; } ];
  };
}
