{
  self,
  inputs,
  ...
}:
{
  flake.modules.nixos.renato-notebook =
    { pkgs, config, ... }:
    {
      imports = with self.modules.nixos; [
        base
        renatofg
        helena
      ];

      nixpkgs.hostPlatform = "x86_64-linux";

      boot = {
        initrd = {
          availableKernelModules = [
            "xhci_pci"
            "thunderbolt"
            "vmd"
            "nvme"
            "usb_storage"
            "sd_mod"
            "rtsx_pci_sdmmc"
          ];
          kernelModules = [ ];
        };
        kernelModules = [ "kvm-intel" ];
        kernelParams = [ "i915.enable_guc=3" ];
        extraModulePackages = [ ];
      };

      networking = {
        hostName = "renato-notebook";
        interfaces.wlp0s20f3.useDHCP = false;
      };

      hardware = {
        acpilight.enable = true;
        cpu.intel.updateMicrocode = config.hardware.enableRedistributableFirmware;
      };

      services.xserver.displayManager.setupCommands = ''
        ${pkgs.xorg.xrandr}/bin/xrandr --output "eDP-1" --mode "1920x1200"
      '';
    };

  flake.nixosConfigurations.renato-notebook = inputs.nixpkgs.lib.nixosSystem {
    modules = [

      self.modules.nixos.renato-notebook

      inputs.home-manager.nixosModules.home-manager

      {
        home-manager = {
          useGlobalPkgs = true;
          users.renatofg = self.modules.homeManager.renatofg;
        };
      }

      {
        nixpkgs = {
          config.allowUnfree = true;
          overlays = [ self.overlays.default ];
        };
      }

    ];
  };

}
