{
  flake.modules.nixos.renato-notebook = {
    fileSystems."/" = {
      device = "/dev/disk/by-uuid/da3526eb-0d3d-42d0-81af-6a5efe97b279";
      fsType = "ext4";
    };

    fileSystems."/boot" = {
      device = "/dev/disk/by-uuid/D7FE-168A";
      fsType = "vfat";
    };

    swapDevices = [
      { device = "/dev/disk/by-uuid/e10fe52a-5c6c-46ca-824f-257dd9a43515"; }
    ];
  };
}
