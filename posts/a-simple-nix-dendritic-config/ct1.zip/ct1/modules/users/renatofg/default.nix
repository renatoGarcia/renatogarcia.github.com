{
  flake.modules.nixos.renatofg = {
    users.users.renatofg = {
      isNormalUser = true;
      extraGroups = [
        "wheel"
        "users"
        "video"
        "input"
        "vboxusers"
        "networkmanager"
        "docker"
        "libvirtd"
        "kvm"
        "qemu-libvirtd"
      ];
      uid = 1000;
    };
  };

  flake.modules.homeManager.renatofg =
    {
      home = {
        username = "renatofg";
        homeDirectory = "/home/renatofg";
        stateVersion = "22.05";
      };

      gtk.colorScheme = "dark";
      xdg.configFile."starship.toml".source = ./_dotfiles/starship.toml;
    };
}
