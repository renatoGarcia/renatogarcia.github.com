{
  flake.modules.nixos.helena = {
    users.users.helena = {
      isNormalUser = true;
      extraGroups = [
        "users"
        "video"
        "input"
        "networkmanager"
      ];
      uid = 1001;
    };
  };
}
